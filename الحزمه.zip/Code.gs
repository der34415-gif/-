/**
 * بوابة تسليم الواجبات — Google Apps Script
 * ينشئ صفًا في Google Sheets ويحفظ الصورة في مجلد Google Drive.
 * شغّل setup() مرة واحدة من محرر Apps Script ووافق على الصلاحيات.
 */
const CONFIG = {
  SPREADSHEET_NAME: 'سجل تسليم الواجبات',
  DRIVE_FOLDER_NAME: 'صور واجبات الطلاب'
};

function setup() {
  const props = PropertiesService.getScriptProperties();
  let ssId = props.getProperty('SPREADSHEET_ID');
  let folderId = props.getProperty('FOLDER_ID');
  let ss, folder;

  if (ssId) {
    try { ss = SpreadsheetApp.openById(ssId); } catch (e) {}
  }
  if (!ss) {
    ss = SpreadsheetApp.create(CONFIG.SPREADSHEET_NAME);
    props.setProperty('SPREADSHEET_ID', ss.getId());
  }

  if (folderId) {
    try { folder = DriveApp.getFolderById(folderId); } catch (e) {}
  }
  if (!folder) {
    folder = DriveApp.createFolder(CONFIG.DRIVE_FOLDER_NAME);
    props.setProperty('FOLDER_ID', folder.getId());
  }

  let sheet = ss.getSheetByName('التسليمات');
  if (!sheet) sheet = ss.getSheets()[0].setName('التسليمات');
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(['تاريخ الإرسال','اسم الطالب','الصف','الشعبة','عنوان الواجب','رابط الصورة','اسم الملف']);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,7).setFontWeight('bold');
  }
  Logger.log('رابط سجل الواجبات: ' + ss.getUrl());
  Logger.log('رابط مجلد الصور: ' + folder.getUrl());
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const name = String(data.studentName || '').trim();
    const grade = String(data.grade || '').trim();
    const section = String(data.section || '').trim();
    const title = String(data.homeworkTitle || '').trim();
    const mimeType = String(data.mimeType || '');
    const fileName = String(data.fileName || 'homework-image').replace(/[\\/:*?"<>|]/g, '_');
    const base64 = String(data.imageBase64 || '');

    if (!name || !grade || !section || !base64) throw new Error('بيانات ناقصة');
    if (!['image/jpeg','image/png','image/webp'].includes(mimeType)) throw new Error('صيغة صورة غير مدعومة');
    if (base64.length > 12 * 1024 * 1024) throw new Error('الصورة كبيرة جدًا');

    const props = PropertiesService.getScriptProperties();
    const folder = DriveApp.getFolderById(props.getProperty('FOLDER_ID'));
    const ss = SpreadsheetApp.openById(props.getProperty('SPREADSHEET_ID'));
    const bytes = Utilities.base64Decode(base64);
    const blob = Utilities.newBlob(bytes, mimeType, fileName);
    const file = folder.createFile(blob);
    file.setDescription('واجب الطالب: ' + name + ' — ' + grade + ' — ' + section);
    const sheet = ss.getSheetByName('التسليمات');
    sheet.appendRow([new Date(), name, grade, section, title, file.getUrl(), fileName]);
    return ContentService.createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false, error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService.createTextOutput('بوابة تسليم الواجبات تعمل.')
    .setMimeType(ContentService.MimeType.TEXT);
}
